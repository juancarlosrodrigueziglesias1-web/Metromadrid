package app.madridtrenmetro.data.gtfs

import java.io.StringReader
import org.junit.Assert.assertEquals
import org.junit.Test

class CsvParserTest {

    private fun parse(text: String) = CsvParser.parse(StringReader(text)).toList()

    @Test
    fun parsesSimpleRows() {
        assertEquals(listOf(listOf("a", "b"), listOf("1", "2")), parse("a,b\n1,2\n"))
    }

    @Test
    fun handlesCrLfAndMissingFinalNewline() {
        assertEquals(listOf(listOf("a", "b"), listOf("1", "2")), parse("a,b\r\n1,2"))
    }

    @Test
    fun handlesQuotedCommasAndEscapedQuotes() {
        assertEquals(
            listOf(listOf("x", "Sol, Madrid", "say \"hi\"")),
            parse("x,\"Sol, Madrid\",\"say \"\"hi\"\"\"\n"),
        )
    }

    @Test
    fun handlesNewlineInsideQuotes() {
        assertEquals(listOf(listOf("a", "line1\nline2")), parse("a,\"line1\nline2\"\n"))
    }

    @Test
    fun stripsBomAndSkipsBlankLines() {
        assertEquals(listOf(listOf("id", "name"), listOf("1", "Sol")), parse("\uFEFFid,name\n\n1,Sol\n\n"))
    }

    @Test
    fun keepsEmptyFields() {
        assertEquals(listOf(listOf("a", "", "c")), parse("a,,c\n"))
    }
}
