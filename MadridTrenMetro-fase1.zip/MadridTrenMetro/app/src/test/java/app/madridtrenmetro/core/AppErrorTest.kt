package app.madridtrenmetro.core

import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.zip.ZipException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AppErrorTest {

    @Test
    fun networkFailuresMapToNoConnection() {
        assertTrue(UnknownHostException().toAppError() is AppError.NoConnection)
        assertTrue(IOException("reset").toAppError() is AppError.NoConnection)
    }

    @Test
    fun timeoutMapsToTimeout() {
        assertTrue(SocketTimeoutException().toAppError() is AppError.Timeout)
    }

    @Test
    fun corruptZipMapsToInvalidData() {
        assertTrue(ZipException("bad").toAppError() is AppError.InvalidData)
    }

    @Test
    fun unknownExceptionsMapToUnknown() {
        assertTrue(IllegalStateException().toAppError() is AppError.Unknown)
    }

    @Test
    fun appErrorsPassThrough() {
        val error = AppError.Server(503)
        assertTrue(error.toAppError() === error)
    }

    @Test
    fun safeCallWrapsFailuresAndReturnsValues() {
        assertEquals(42, safeCall { 42 }.getOrNull())
        val failure = safeCall<Int> { throw UnknownHostException() }
        assertTrue(failure.exceptionOrNull() is AppError.NoConnection)
    }
}
