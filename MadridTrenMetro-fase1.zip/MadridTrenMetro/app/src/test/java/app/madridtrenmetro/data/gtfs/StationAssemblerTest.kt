package app.madridtrenmetro.data.gtfs

import app.madridtrenmetro.domain.model.TransportMode
import org.junit.Assert.assertEquals
import org.junit.Test

class StationAssemblerTest {

    private fun stop(id: String, name: String, type: Int, parent: String? = null, lat: Double? = null, lon: Double? = null) =
        GtfsStop(id, name, lat, lon, type, parent)

    @Test
    fun prefersStationsAndIgnoresPlatforms() {
        val stops = listOf(
            stop("par_sol", "SOL", 1, lat = 40.0, lon = -3.0),
            stop("est_sol_1", "SOL", 0, "par_sol"),
            stop("par_atocha", "Atocha", 1),
        )

        val stations = StationAssembler.assemble(TransportMode.METRO, stops)

        assertEquals(listOf("Atocha", "Sol"), stations.map { it.name })
        assertEquals(listOf("par_sol"), stations.first { it.name == "Sol" }.stopIds)
    }

    @Test
    fun mergesStationsWithTheSameNormalizedName() {
        val stops = listOf(
            stop("par_l1", "Príncipe Pío", 1, lat = 40.0, lon = -3.0),
            stop("par_l6", "PRINCIPE PIO", 1, lat = 42.0, lon = -5.0),
        )

        val stations = StationAssembler.assemble(TransportMode.METRO, stops)

        assertEquals(1, stations.size)
        assertEquals("METRO:principe pio", stations[0].id)
        assertEquals(listOf("par_l1", "par_l6"), stations[0].stopIds)
        assertEquals(41.0, stations[0].latitude!!, 1e-9)
        assertEquals(-4.0, stations[0].longitude!!, 1e-9)
    }

    @Test
    fun fallsBackToPlainStopsWhenFeedHasNoStations() {
        val stops = listOf(stop("1", "Chamartín", 0), stop("2", "Atocha", 0), stop("3", "Entrada", 2))

        val stations = StationAssembler.assemble(TransportMode.CERCANIAS, stops)

        assertEquals(listOf("Atocha", "Chamartín"), stations.map { it.name })
        assertEquals(TransportMode.CERCANIAS, stations[0].mode)
    }
}
