package app.madridtrenmetro.data.gtfs

import app.madridtrenmetro.core.AppError
import java.io.StringReader
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test

class GtfsStopsParserTest {

    @Test
    fun parsesColumnsInAnyOrder() {
        val csv = """
            stop_name,stop_id,location_type,stop_lon,stop_lat,parent_station
            Sol,par_1,1,-3.7035,40.4169,
            Sol,est_1,0,-3.7036,40.4170,par_1
        """.trimIndent()

        val stops = GtfsStopsParser.parse(StringReader(csv))

        assertEquals(2, stops.size)
        assertEquals(GtfsStop("par_1", "Sol", 40.4169, -3.7035, 1, null), stops[0])
        assertEquals("par_1", stops[1].parentId)
    }

    @Test
    fun toleratesMissingOptionalColumnsAndBadNumbers() {
        val csv = "stop_id,stop_name,stop_lat\nA,Alpha,not-a-number\nB,,1.0\n,NoId,2.0\n"

        val stops = GtfsStopsParser.parse(StringReader(csv))

        assertEquals(1, stops.size)
        assertNull(stops[0].latitude)
        assertEquals(0, stops[0].locationType)
    }

    @Test
    fun failsWhenRequiredColumnsAreMissing() {
        assertThrows(AppError.InvalidData::class.java) {
            GtfsStopsParser.parse(StringReader("stop_id,lat\nA,1\n"))
        }
        assertThrows(AppError.InvalidData::class.java) {
            GtfsStopsParser.parse(StringReader(""))
        }
    }
}
