package app.madridtrenmetro.core

import org.junit.Assert.assertEquals
import org.junit.Test

class StationNamesTest {

    @Test
    fun normalizeRemovesAccentsCaseAndPunctuation() {
        assertEquals("nunez de balboa", "Núñez de Balboa".normalizeForSearch())
        assertEquals("madrid atocha cercanias", "MADRID-ATOCHA (Cercanías)".normalizeForSearch())
        assertEquals("", "  --  ".normalizeForSearch())
    }

    @Test
    fun displayNameConvertsUppercaseToTitleCase() {
        assertEquals("Madrid-Atocha", "MADRID-ATOCHA".toDisplayName())
        assertEquals("Alcalá De Henares", "ALCALÁ DE HENARES".toDisplayName())
    }

    @Test
    fun displayNameKeepsMixedCaseNames() {
        assertEquals("Cuatro Caminos", "Cuatro Caminos".toDisplayName())
        assertEquals("Sol", "  Sol ".toDisplayName())
    }
}
