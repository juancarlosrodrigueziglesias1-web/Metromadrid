package app.madridtrenmetro.ui.search

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.madridtrenmetro.core.AppError
import app.madridtrenmetro.domain.model.Station
import app.madridtrenmetro.domain.model.TransportMode
import app.madridtrenmetro.domain.repository.StationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SearchUiState(
    val mode: TransportMode? = null,
    /** Consulta a la que corresponden [results]; permite saber si hay una búsqueda pendiente. */
    val resultsQuery: String = "",
    val results: List<Station> = emptyList(),
    val stationCount: Int = 0,
    val isSyncing: Boolean = false,
    val failedModes: Map<TransportMode, AppError> = emptyMap(),
)

private data class SyncState(
    val isSyncing: Boolean = false,
    val failures: Map<TransportMode, AppError> = emptyMap(),
)

private data class SearchResults(val query: String, val stations: List<Station>)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val repository: StationRepository,
    private val savedStateHandle: SavedStateHandle,
) : ViewModel() {

    val query: StateFlow<String> = savedStateHandle.getStateFlow(KEY_QUERY, "")

    private val mode = MutableStateFlow<TransportMode?>(null)
    private val syncState = MutableStateFlow(SyncState())
    private var syncJob: Job? = null

    private val results: Flow<SearchResults> = combine(
        query.debounce(SEARCH_DEBOUNCE_MS),
        mode,
        repository.observeStationCount(),
    ) { text, selectedMode, _ -> text to selectedMode }
        .mapLatest { (text, selectedMode) ->
            SearchResults(text, repository.search(text, selectedMode))
        }

    val uiState: StateFlow<SearchUiState> = combine(
        results,
        mode,
        repository.observeStationCount(),
        syncState,
    ) { found, selectedMode, count, sync ->
        SearchUiState(
            mode = selectedMode,
            resultsQuery = found.query,
            results = found.stations,
            stationCount = count,
            isSyncing = sync.isSyncing,
            failedModes = sync.failures,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SearchUiState())

    init {
        refresh(force = false)
    }

    fun onQueryChange(value: String) {
        savedStateHandle[KEY_QUERY] = value
    }

    fun onModeChange(value: TransportMode?) {
        mode.value = value
    }

    fun retry() = refresh(force = true)

    private fun refresh(force: Boolean) {
        if (syncJob?.isActive == true) return
        syncJob = viewModelScope.launch {
            syncState.value = SyncState(isSyncing = true)
            val report = repository.sync(force)
            syncState.value = SyncState(isSyncing = false, failures = report.failures)
        }
    }

    private companion object {
        const val KEY_QUERY = "query"
        const val SEARCH_DEBOUNCE_MS = 120L
    }
}
