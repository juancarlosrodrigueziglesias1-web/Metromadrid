package app.madridtrenmetro.data.gtfs

import java.io.BufferedReader
import java.io.Reader

/** Lector CSV mínimo (RFC 4180): comillas, comillas escapadas, saltos de línea dentro de campos y BOM. */
object CsvParser {

    /** Secuencia perezosa: debe consumirse mientras el [reader] siga abierto. */
    fun parse(reader: Reader): Sequence<List<String>> = sequence {
        val input = if (reader is BufferedReader) reader else BufferedReader(reader)
        val field = StringBuilder()
        var row = ArrayList<String>()
        var inQuotes = false
        var recordStarted = false
        var firstChar = true

        while (true) {
            val code = input.read()
            if (code == -1) break
            val ch = code.toChar()
            if (firstChar) {
                firstChar = false
                if (ch == '\uFEFF') continue
            }
            if (inQuotes) {
                if (ch == '"') {
                    input.mark(1)
                    val next = input.read()
                    if (next == '"'.code) {
                        field.append('"')
                    } else {
                        inQuotes = false
                        if (next != -1) input.reset()
                    }
                } else {
                    field.append(ch)
                }
            } else {
                when (ch) {
                    '"' -> {
                        inQuotes = true
                        recordStarted = true
                    }
                    ',' -> {
                        row.add(field.toString())
                        field.setLength(0)
                        recordStarted = true
                    }
                    '\r' -> Unit
                    '\n' -> {
                        if (recordStarted) {
                            row.add(field.toString())
                            yield(row)
                        }
                        row = ArrayList()
                        field.setLength(0)
                        recordStarted = false
                    }
                    else -> {
                        field.append(ch)
                        recordStarted = true
                    }
                }
            }
        }
        if (recordStarted) {
            row.add(field.toString())
            yield(row)
        }
    }
}
