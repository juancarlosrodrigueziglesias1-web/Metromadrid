package app.madridtrenmetro.domain.repository

import app.madridtrenmetro.core.AppError
import app.madridtrenmetro.domain.model.Station
import app.madridtrenmetro.domain.model.TransportMode
import kotlinx.coroutines.flow.Flow

data class SyncReport(
    val updated: Set<TransportMode>,
    val failures: Map<TransportMode, AppError>,
)

interface StationRepository {
    fun observeStationCount(): Flow<Int>

    /** Última sincronización correcta de cada modo (milisegundos desde epoch). */
    fun observeLastSync(): Flow<Map<TransportMode, Long>>

    suspend fun search(query: String, mode: TransportMode?, limit: Int = 30): List<Station>

    suspend fun getStation(id: String): Station?

    /** Descarga el listado de estaciones si no hay datos o están caducados (o si [force]). */
    suspend fun sync(force: Boolean = false): SyncReport
}
