package app.madridtrenmetro.ui.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.madridtrenmetro.ui.search.SearchRoute
import app.madridtrenmetro.ui.station.StationRoute

@Composable
fun AppNavHost() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Routes.SEARCH,
        enterTransition = { slideInHorizontally(initialOffsetX = { it / 4 }) + fadeIn() },
        exitTransition = { fadeOut() },
        popEnterTransition = { fadeIn() },
        popExitTransition = { slideOutHorizontally(targetOffsetX = { it / 4 }) + fadeOut() },
    ) {
        composable(Routes.SEARCH) {
            SearchRoute(
                onStationSelected = { station -> navController.navigate(Routes.station(station.id)) },
            )
        }
        composable(
            route = Routes.STATION,
            arguments = listOf(navArgument(Routes.STATION_ARG) { type = NavType.StringType }),
        ) {
            StationRoute(onBack = { navController.popBackStack() })
        }
    }
}
