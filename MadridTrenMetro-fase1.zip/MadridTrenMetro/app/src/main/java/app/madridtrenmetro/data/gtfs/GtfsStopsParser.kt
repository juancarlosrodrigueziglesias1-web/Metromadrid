package app.madridtrenmetro.data.gtfs

import app.madridtrenmetro.core.AppError
import java.io.Reader
import java.util.Locale

data class GtfsStop(
    val id: String,
    val name: String,
    val latitude: Double?,
    val longitude: Double?,
    /** 0 = parada/andén, 1 = estación, otros valores según la especificación GTFS. */
    val locationType: Int,
    val parentId: String?,
)

/** Lee `stops.txt` de un feed GTFS sin depender de un orden fijo de columnas. */
object GtfsStopsParser {

    fun parse(reader: Reader): List<GtfsStop> {
        val rows = CsvParser.parse(reader).iterator()
        if (!rows.hasNext()) throw AppError.InvalidData("stops.txt is empty")

        val header = rows.next().map { it.trim().lowercase(Locale.ROOT) }
        val columns = header.withIndex().associate { it.value to it.index }
        val idCol = columns["stop_id"] ?: throw AppError.InvalidData("stops.txt has no stop_id column")
        val nameCol = columns["stop_name"] ?: throw AppError.InvalidData("stops.txt has no stop_name column")
        val latCol = columns["stop_lat"]
        val lonCol = columns["stop_lon"]
        val typeCol = columns["location_type"]
        val parentCol = columns["parent_station"]

        return buildList {
            for (row in rows) {
                val id = row.column(idCol) ?: continue
                val name = row.column(nameCol) ?: continue
                add(
                    GtfsStop(
                        id = id,
                        name = name,
                        latitude = row.column(latCol)?.toDoubleOrNull(),
                        longitude = row.column(lonCol)?.toDoubleOrNull(),
                        locationType = row.column(typeCol)?.toIntOrNull() ?: 0,
                        parentId = row.column(parentCol),
                    ),
                )
            }
        }
    }
}

private fun List<String>.column(index: Int?): String? {
    if (index == null) return null
    return getOrNull(index)?.trim()?.takeIf { it.isNotEmpty() }
}
