package app.madridtrenmetro.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "stations",
    indices = [Index("mode"), Index("searchName")],
)
data class StationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val searchName: String,
    val mode: String,
    val stopIds: String,
    val latitude: Double?,
    val longitude: Double?,
)

@Entity(tableName = "sync_state")
data class SyncStateEntity(
    @PrimaryKey val mode: String,
    val syncedAtMillis: Long,
)
