package app.madridtrenmetro.core

import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.zip.ZipException
import javax.net.ssl.SSLException
import kotlin.coroutines.cancellation.CancellationException

/** Errores de la aplicación, ya clasificados para poder mostrarlos al usuario. */
sealed class AppError(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class NoConnection(cause: Throwable? = null) : AppError("No network connection", cause)
    class Timeout(cause: Throwable? = null) : AppError("Request timed out", cause)
    class Server(val httpCode: Int?, cause: Throwable? = null) :
        AppError("Server error (${httpCode ?: "unknown"})", cause)

    class InvalidData(detail: String, cause: Throwable? = null) :
        AppError("Invalid data: $detail", cause)

    class Unknown(cause: Throwable? = null) : AppError("Unexpected error", cause)
}

fun Throwable.toAppError(): AppError = when (this) {
    is AppError -> this
    is UnknownHostException, is ConnectException -> AppError.NoConnection(this)
    is SocketTimeoutException -> AppError.Timeout(this)
    is SSLException -> AppError.Server(null, this)
    is ZipException -> AppError.InvalidData("corrupt archive", this)
    is IOException -> AppError.NoConnection(this)
    else -> AppError.Unknown(this)
}

/**
 * Ejecuta [block] y devuelve el resultado como [Result], traduciendo las excepciones a [AppError].
 * La cancelación de corrutinas nunca se captura.
 */
inline fun <T> safeCall(block: () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    Result.failure(e.toAppError())
}
