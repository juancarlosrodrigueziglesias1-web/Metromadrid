package app.madridtrenmetro.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [StationEntity::class, SyncStateEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun stationDao(): StationDao
}
