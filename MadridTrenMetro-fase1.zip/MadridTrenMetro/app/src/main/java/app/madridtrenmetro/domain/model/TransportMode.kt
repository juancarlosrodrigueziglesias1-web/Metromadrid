package app.madridtrenmetro.domain.model

/**
 * Modos de transporte soportados. Para añadir autobuses EMT basta con un nuevo valor
 * (y su fuente de datos); la interfaz lo mostrará a partir de las extensiones de UI.
 */
enum class TransportMode {
    METRO,
    CERCANIAS;

    companion object {
        fun fromName(name: String): TransportMode? = entries.firstOrNull { it.name == name }
    }
}
