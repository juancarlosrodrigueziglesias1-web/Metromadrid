package app.madridtrenmetro.data.repository

import app.madridtrenmetro.core.AppError
import app.madridtrenmetro.core.normalizeForSearch
import app.madridtrenmetro.core.safeCall
import app.madridtrenmetro.core.toAppError
import app.madridtrenmetro.data.local.StationDao
import app.madridtrenmetro.data.local.SyncStateEntity
import app.madridtrenmetro.data.local.toDomain
import app.madridtrenmetro.data.local.toEntity
import app.madridtrenmetro.data.source.StationSource
import app.madridtrenmetro.data.source.StationSourceRegistry
import app.madridtrenmetro.domain.model.Station
import app.madridtrenmetro.domain.model.TransportMode
import app.madridtrenmetro.domain.repository.StationRepository
import app.madridtrenmetro.domain.repository.SyncReport
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StationRepositoryImpl @Inject constructor(
    private val dao: StationDao,
    private val registry: StationSourceRegistry,
) : StationRepository {

    override fun observeStationCount(): Flow<Int> = dao.observeCount()

    override fun observeLastSync(): Flow<Map<TransportMode, Long>> =
        dao.observeSyncStates().map { states ->
            states.mapNotNull { state ->
                TransportMode.fromName(state.mode)?.let { mode -> mode to state.syncedAtMillis }
            }.toMap()
        }

    override suspend fun search(query: String, mode: TransportMode?, limit: Int): List<Station> {
        val normalized = query.normalizeForSearch()
        if (normalized.isEmpty()) return emptyList()
        return dao.search(normalized, mode?.name, limit).mapNotNull { it.toDomain() }
    }

    override suspend fun getStation(id: String): Station? = dao.byId(id)?.toDomain()

    override suspend fun sync(force: Boolean): SyncReport = coroutineScope {
        val outcomes = registry.sources
            .map { source -> async { source.mode to syncSource(source, force) } }
            .awaitAll()

        val updated = outcomes
            .filter { (_, result) -> result.getOrNull() == true }
            .map { (mode, _) -> mode }
            .toSet()
        val failures = outcomes
            .mapNotNull { (mode, result) -> result.exceptionOrNull()?.let { mode to it.toAppError() } }
            .toMap<TransportMode, AppError>()
        SyncReport(updated = updated, failures = failures)
    }

    /** Devuelve `true` si se descargaron datos nuevos, `false` si los guardados siguen vigentes. */
    private suspend fun syncSource(source: StationSource, force: Boolean): Result<Boolean> {
        val modeName = source.mode.name
        if (!force && isFresh(modeName)) return Result.success(false)

        return safeCall {
            val stations = source.fetchStations()
            dao.replaceMode(
                mode = modeName,
                stations = stations.map { it.toEntity() },
                state = SyncStateEntity(modeName, System.currentTimeMillis()),
            )
            true
        }
    }

    private suspend fun isFresh(modeName: String): Boolean {
        val state = dao.syncState(modeName) ?: return false
        val age = System.currentTimeMillis() - state.syncedAtMillis
        return age in 0 until STALE_AFTER_MILLIS && dao.countByMode(modeName) > 0
    }

    private companion object {
        val STALE_AFTER_MILLIS: Long = TimeUnit.DAYS.toMillis(7)
    }
}
