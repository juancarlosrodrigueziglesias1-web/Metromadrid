package app.madridtrenmetro.di

import android.content.Context
import androidx.room.Room
import app.madridtrenmetro.data.gtfs.GtfsDownloader
import app.madridtrenmetro.data.local.AppDatabase
import app.madridtrenmetro.data.local.StationDao
import app.madridtrenmetro.data.repository.StationRepositoryImpl
import app.madridtrenmetro.data.source.FeedUrls
import app.madridtrenmetro.data.source.GtfsStationSource
import app.madridtrenmetro.data.source.StationSourceRegistry
import app.madridtrenmetro.domain.model.TransportMode
import app.madridtrenmetro.domain.repository.StationRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DataModule {

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(2, TimeUnit.MINUTES)
        .build()

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "madrid_tren_metro.db").build()

    @Provides
    fun provideStationDao(database: AppDatabase): StationDao = database.stationDao()

    @Provides
    @Singleton
    fun provideStationSources(downloader: GtfsDownloader): StationSourceRegistry =
        StationSourceRegistry(
            listOf(
                GtfsStationSource(TransportMode.METRO, FeedUrls.METRO_GTFS, downloader),
                GtfsStationSource(TransportMode.CERCANIAS, FeedUrls.CERCANIAS_GTFS, downloader),
            ),
        )
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindStationRepository(impl: StationRepositoryImpl): StationRepository
}
