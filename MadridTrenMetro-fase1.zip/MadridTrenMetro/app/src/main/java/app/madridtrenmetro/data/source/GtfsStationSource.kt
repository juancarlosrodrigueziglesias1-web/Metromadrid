package app.madridtrenmetro.data.source

import app.madridtrenmetro.core.AppError
import app.madridtrenmetro.data.gtfs.GtfsDownloader
import app.madridtrenmetro.data.gtfs.GtfsStopsParser
import app.madridtrenmetro.data.gtfs.StationAssembler
import app.madridtrenmetro.domain.model.Station
import app.madridtrenmetro.domain.model.TransportMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GtfsStationSource(
    override val mode: TransportMode,
    private val feedUrl: String,
    private val downloader: GtfsDownloader,
) : StationSource {

    override suspend fun fetchStations(): List<Station> = withContext(Dispatchers.IO) {
        val stops = downloader.readEntry(feedUrl, "stops.txt") { reader -> GtfsStopsParser.parse(reader) }
        val stations = StationAssembler.assemble(mode, stops)
        if (stations.isEmpty()) throw AppError.InvalidData("feed for $mode contains no stations")
        stations
    }
}
