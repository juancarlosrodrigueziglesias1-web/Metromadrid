package app.madridtrenmetro.ui.station

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.madridtrenmetro.domain.model.Station
import app.madridtrenmetro.domain.repository.StationRepository
import app.madridtrenmetro.ui.navigation.Routes
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

sealed interface StationUiState {
    data object Loading : StationUiState
    data object NotFound : StationUiState
    data class Found(val station: Station) : StationUiState
}

@HiltViewModel
class StationViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: StationRepository,
) : ViewModel() {

    private val stationId: String = checkNotNull(savedStateHandle.get<String>(Routes.STATION_ARG))

    val uiState: StateFlow<StationUiState> = flow {
        val station = repository.getStation(stationId)
        emit(if (station != null) StationUiState.Found(station) else StationUiState.NotFound)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StationUiState.Loading)
}
