package app.madridtrenmetro.ui.navigation

import android.net.Uri

object Routes {
    const val SEARCH = "search"
    const val STATION_ARG = "stationId"
    const val STATION = "station/{$STATION_ARG}"

    fun station(stationId: String): String = "station/${Uri.encode(stationId)}"
}
