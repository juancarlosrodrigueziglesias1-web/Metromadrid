package app.madridtrenmetro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import app.madridtrenmetro.ui.navigation.AppNavHost
import app.madridtrenmetro.ui.theme.MadridTrenMetroTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MadridTrenMetroTheme {
                AppNavHost()
            }
        }
    }
}
