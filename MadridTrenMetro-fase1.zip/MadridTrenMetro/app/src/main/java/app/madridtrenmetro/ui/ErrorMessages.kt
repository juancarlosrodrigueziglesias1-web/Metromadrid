package app.madridtrenmetro.ui

import androidx.annotation.StringRes
import app.madridtrenmetro.R
import app.madridtrenmetro.core.AppError

@StringRes
fun AppError.messageRes(): Int = when (this) {
    is AppError.NoConnection -> R.string.error_no_connection
    is AppError.Timeout -> R.string.error_timeout
    is AppError.Server -> R.string.error_server
    is AppError.InvalidData -> R.string.error_invalid_data
    is AppError.Unknown -> R.string.error_unknown
}
