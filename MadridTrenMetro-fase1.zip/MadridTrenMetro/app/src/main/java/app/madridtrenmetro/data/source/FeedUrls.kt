package app.madridtrenmetro.data.source

/**
 * URLs de los feeds GTFS estáticos del Consorcio Regional de Transportes de Madrid (CRTM).
 *
 * Son horarios programados: sirven para el catálogo de estaciones. La versión vigente del
 * feed de Metro se publica también en el Punto de Acceso Nacional (NAP), que exige ApiKey;
 * cuando haya clave se añadirá como fuente adicional sin cambiar el resto del código.
 */
object FeedUrls {
    const val METRO_GTFS =
        "https://crtm.maps.arcgis.com/sharing/rest/content/items/5c7f2951962540d69ffe8f640d94c246/data"
    const val CERCANIAS_GTFS =
        "https://www.arcgis.com/sharing/rest/content/items/1a25440bf66f499bae2657ec7fb40144/data"
}
