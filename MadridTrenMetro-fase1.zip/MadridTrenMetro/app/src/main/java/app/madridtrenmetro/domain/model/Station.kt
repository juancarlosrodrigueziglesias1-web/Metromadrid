package app.madridtrenmetro.domain.model

data class Station(
    /** Identificador estable: modo + nombre normalizado. */
    val id: String,
    val name: String,
    val mode: TransportMode,
    /** Identificadores GTFS de las paradas/andenes que componen la estación. */
    val stopIds: List<String>,
    val latitude: Double?,
    val longitude: Double?,
)
