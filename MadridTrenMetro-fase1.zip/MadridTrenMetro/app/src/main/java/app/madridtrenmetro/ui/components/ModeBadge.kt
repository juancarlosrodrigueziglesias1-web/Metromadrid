package app.madridtrenmetro.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.madridtrenmetro.domain.model.TransportMode

@Composable
fun ModeBadge(
    mode: TransportMode,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(mode.accentColor()),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(mode.iconRes()),
            contentDescription = stringResource(mode.labelRes()),
            tint = Color.White,
            modifier = Modifier.size(size * 0.55f),
        )
    }
}
