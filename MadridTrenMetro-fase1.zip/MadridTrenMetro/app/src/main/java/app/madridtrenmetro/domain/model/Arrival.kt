package app.madridtrenmetro.domain.model

import java.time.Instant

/** Contrato de llegada que usarán las fases siguientes. */
data class Arrival(
    val line: String,
    val destination: String,
    val platform: String?,
    val expectedAt: Instant,
    val delaySeconds: Int?,
    val quality: DataQuality,
)
