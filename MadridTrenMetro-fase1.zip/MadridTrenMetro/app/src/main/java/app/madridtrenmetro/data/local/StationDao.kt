package app.madridtrenmetro.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
abstract class StationDao {

    @Query(
        """
        SELECT * FROM stations
        WHERE (:mode IS NULL OR mode = :mode) AND searchName LIKE '%' || :query || '%'
        ORDER BY CASE WHEN searchName LIKE :query || '%' THEN 0 ELSE 1 END, name COLLATE NOCASE
        LIMIT :limit
        """,
    )
    abstract suspend fun search(query: String, mode: String?, limit: Int): List<StationEntity>

    @Query("SELECT * FROM stations WHERE id = :id")
    abstract suspend fun byId(id: String): StationEntity?

    @Query("SELECT COUNT(*) FROM stations")
    abstract fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM stations WHERE mode = :mode")
    abstract suspend fun countByMode(mode: String): Int

    @Query("SELECT * FROM sync_state")
    abstract fun observeSyncStates(): Flow<List<SyncStateEntity>>

    @Query("SELECT * FROM sync_state WHERE mode = :mode")
    abstract suspend fun syncState(mode: String): SyncStateEntity?

    @Query("DELETE FROM stations WHERE mode = :mode")
    abstract suspend fun deleteByMode(mode: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertAll(stations: List<StationEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun upsertSyncState(state: SyncStateEntity)

    /** Reemplaza las estaciones de un modo de forma atómica: si falla, se conservan las anteriores. */
    @Transaction
    open suspend fun replaceMode(mode: String, stations: List<StationEntity>, state: SyncStateEntity) {
        deleteByMode(mode)
        insertAll(stations)
        upsertSyncState(state)
    }
}
