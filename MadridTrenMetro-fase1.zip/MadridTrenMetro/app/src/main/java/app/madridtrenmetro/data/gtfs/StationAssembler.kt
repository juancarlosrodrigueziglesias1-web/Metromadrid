package app.madridtrenmetro.data.gtfs

import app.madridtrenmetro.core.normalizeForSearch
import app.madridtrenmetro.core.toDisplayName
import app.madridtrenmetro.domain.model.Station
import app.madridtrenmetro.domain.model.TransportMode

/**
 * Convierte las paradas GTFS en estaciones de usuario.
 *
 * Se usan las estaciones (`location_type = 1`) si el feed las define; si no, las paradas
 * normales. Las entradas con el mismo nombre (por ejemplo, un andén por línea) se fusionan.
 */
object StationAssembler {

    fun assemble(mode: TransportMode, stops: List<GtfsStop>): List<Station> {
        val stations = stops.filter { it.locationType == 1 }
        val candidates = stations.ifEmpty { stops.filter { it.locationType == 0 } }

        return candidates
            .groupBy { it.name.normalizeForSearch() }
            .filterKeys { it.isNotEmpty() }
            .map { (key, group) ->
                val latitudes = group.mapNotNull { it.latitude }
                val longitudes = group.mapNotNull { it.longitude }
                Station(
                    id = "${mode.name}:$key",
                    name = group.first().name.toDisplayName(),
                    mode = mode,
                    stopIds = group.map { it.id }.distinct(),
                    latitude = if (latitudes.isEmpty()) null else latitudes.average(),
                    longitude = if (longitudes.isEmpty()) null else longitudes.average(),
                )
            }
            .sortedBy { it.name.normalizeForSearch() }
    }
}
