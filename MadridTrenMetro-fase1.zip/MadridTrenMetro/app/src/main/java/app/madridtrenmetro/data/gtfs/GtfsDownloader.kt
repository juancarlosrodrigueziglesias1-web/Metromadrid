package app.madridtrenmetro.data.gtfs

import app.madridtrenmetro.core.AppError
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.InputStreamReader
import java.io.Reader
import java.util.zip.ZipInputStream
import javax.inject.Inject
import javax.inject.Singleton

/** Descarga un feed GTFS (zip) y lee un único fichero de su interior sin guardarlo en disco. */
@Singleton
class GtfsDownloader @Inject constructor(private val client: OkHttpClient) {

    /** Bloqueante: llamar desde un dispatcher de E/S. */
    fun <T> readEntry(url: String, entryName: String, block: (Reader) -> T): T {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw AppError.Server(response.code)
            val body = response.body ?: throw AppError.InvalidData("empty response body")

            ZipInputStream(body.byteStream()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.name.substringAfterLast('/').equals(entryName, ignoreCase = true)) {
                        return block(InputStreamReader(zip, Charsets.UTF_8))
                    }
                }
            }
            throw AppError.InvalidData("GTFS archive does not contain $entryName")
        }
    }

    private companion object {
        const val USER_AGENT = "MadridTrenMetro/0.1 (Android)"
    }
}
