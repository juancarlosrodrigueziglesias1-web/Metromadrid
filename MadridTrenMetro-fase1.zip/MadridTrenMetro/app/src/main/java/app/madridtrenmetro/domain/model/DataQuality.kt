package app.madridtrenmetro.domain.model

/** Origen de un dato horario. La UI debe mostrarlo siempre al usuario. */
enum class DataQuality {
    /** Dato de un feed en tiempo real. */
    REALTIME,

    /** Horario teórico (GTFS estático), no refleja retrasos ni incidencias. */
    SCHEDULED,
}
