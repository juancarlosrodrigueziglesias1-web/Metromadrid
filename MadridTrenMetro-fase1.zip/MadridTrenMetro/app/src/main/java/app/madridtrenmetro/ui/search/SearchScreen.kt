package app.madridtrenmetro.ui.search

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.madridtrenmetro.R
import app.madridtrenmetro.core.AppError
import app.madridtrenmetro.domain.model.Station
import app.madridtrenmetro.domain.model.TransportMode
import app.madridtrenmetro.ui.components.ModeBadge
import app.madridtrenmetro.ui.components.labelRes
import app.madridtrenmetro.ui.messageRes

@Composable
fun SearchRoute(
    onStationSelected: (Station) -> Unit,
    viewModel: SearchViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()
    SearchScreen(
        state = state,
        query = query,
        onQueryChange = viewModel::onQueryChange,
        onModeChange = viewModel::onModeChange,
        onRetry = viewModel::retry,
        onStationSelected = onStationSelected,
    )
}

private enum class BodyKind { LOADING, ERROR, HINT, EMPTY, RESULTS }

private fun bodyKind(state: SearchUiState, query: String): BodyKind = when {
    state.stationCount == 0 && state.failedModes.isNotEmpty() && !state.isSyncing -> BodyKind.ERROR
    state.stationCount == 0 -> BodyKind.LOADING
    query.isBlank() -> BodyKind.HINT
    state.results.isEmpty() && state.resultsQuery == query -> BodyKind.EMPTY
    else -> BodyKind.RESULTS
}

@Composable
internal fun SearchScreen(
    state: SearchUiState,
    query: String,
    onQueryChange: (String) -> Unit,
    onModeChange: (TransportMode?) -> Unit,
    onRetry: () -> Unit,
    onStationSelected: (Station) -> Unit,
) {
    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            SearchHeader()
            SearchField(query = query, onQueryChange = onQueryChange)
            ModeFilterRow(selected = state.mode, onSelected = onModeChange)

            AnimatedVisibility(visible = state.isSyncing && state.stationCount > 0) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 4.dp),
                )
            }
            AnimatedVisibility(visible = state.failedModes.isNotEmpty() && state.stationCount > 0) {
                SyncErrorBanner(failures = state.failedModes, onRetry = onRetry)
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) {
                Crossfade(targetState = bodyKind(state, query), label = "searchBody") { kind ->
                    when (kind) {
                        BodyKind.LOADING -> LoadingState()
                        BodyKind.ERROR -> ErrorState(
                            error = state.failedModes.values.firstOrNull(),
                            onRetry = onRetry,
                        )
                        BodyKind.HINT -> HintState(stationCount = state.stationCount)
                        BodyKind.EMPTY -> EmptyState(query = query)
                        BodyKind.RESULTS -> ResultsList(
                            stations = state.results,
                            onStationSelected = onStationSelected,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchHeader() {
    Column(modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 12.dp)) {
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            text = stringResource(R.string.search_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SearchField(query: String, onQueryChange: (String) -> Unit) {
    val focusManager: FocusManager = LocalFocusManager.current
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        placeholder = { Text(stringResource(R.string.search_placeholder)) },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = stringResource(R.string.search_clear),
                    )
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(28.dp),
        keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.Words,
            imeAction = ImeAction.Search,
        ),
        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
    )
}

@Composable
private fun ModeFilterRow(selected: TransportMode?, onSelected: (TransportMode?) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        FilterChip(
            selected = selected == null,
            onClick = { onSelected(null) },
            label = { Text(stringResource(R.string.filter_all)) },
        )
        TransportMode.entries.forEach { mode ->
            FilterChip(
                selected = selected == mode,
                onClick = { onSelected(mode) },
                label = { Text(stringResource(mode.labelRes())) },
            )
        }
    }
}

@Composable
private fun ResultsList(stations: List<Station>, onStationSelected: (Station) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(items = stations, key = { it.id }) { station ->
            StationCard(
                station = station,
                onClick = { onStationSelected(station) },
                modifier = Modifier.animateItem(),
            )
        }
    }
}

@Composable
private fun StationCard(station: Station, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        ),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ModeBadge(mode = station.mode)
            Spacer(Modifier.size(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = station.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = stringResource(station.mode.labelRes()),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun CenteredMessage(
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    leading: @Composable () -> Unit = {},
    actions: @Composable () -> Unit = {},
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        leading()
        Spacer(Modifier.height(16.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(20.dp))
        actions()
    }
}

@Composable
private fun LoadingState() {
    CenteredMessage(
        title = stringResource(R.string.loading_stations),
        body = stringResource(R.string.loading_stations_body),
        leading = { CircularProgressIndicator() },
    )
}

@Composable
private fun HintState(stationCount: Int) {
    CenteredMessage(
        title = stringResource(R.string.search_hint_title),
        body = stringResource(R.string.search_hint_body) + "\n" +
            stringResource(R.string.search_hint_count, stationCount),
        leading = {
            Icon(
                Icons.Default.Search,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
        },
    )
}

@Composable
private fun EmptyState(query: String) {
    CenteredMessage(
        title = stringResource(R.string.search_empty_title),
        body = stringResource(R.string.search_empty_body, query.trim()),
        leading = {
            Icon(
                Icons.Default.Search,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        },
    )
}

@Composable
private fun ErrorState(error: AppError?, onRetry: () -> Unit) {
    val messageRes = error?.messageRes() ?: R.string.error_unknown
    CenteredMessage(
        title = stringResource(R.string.error_title),
        body = stringResource(messageRes),
        leading = {
            Icon(
                Icons.Default.Warning,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.error,
            )
        },
        actions = {
            Button(onClick = onRetry) { Text(stringResource(R.string.action_retry)) }
        },
    )
}

@Composable
private fun SyncErrorBanner(failures: Map<TransportMode, AppError>, onRetry: () -> Unit) {
    val modeNames = failures.keys.map { stringResource(it.labelRes()) }
    val reasonRes = failures.values.firstOrNull()?.messageRes() ?: R.string.error_unknown
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.errorContainer,
    ) {
        Row(
            modifier = Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Default.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onErrorContainer,
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp),
            ) {
                Text(
                    text = stringResource(R.string.sync_banner_title, modeNames.joinToString()),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                )
                Text(
                    text = stringResource(reasonRes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                )
            }
            TextButton(onClick = onRetry) { Text(stringResource(R.string.action_retry)) }
        }
    }
}
