package app.madridtrenmetro.data.source

import app.madridtrenmetro.domain.model.Station
import app.madridtrenmetro.domain.model.TransportMode

/** Origen del catálogo de estaciones de un modo de transporte. */
interface StationSource {
    val mode: TransportMode

    /** Bloqueante o suspendida según la implementación; lanza [app.madridtrenmetro.core.AppError]. */
    suspend fun fetchStations(): List<Station>
}

/** Conjunto de fuentes registradas; añadir un modo nuevo es añadir una entrada aquí. */
class StationSourceRegistry(val sources: List<StationSource>)
