package app.madridtrenmetro.core

import java.text.Normalizer
import java.util.Locale

private val combiningMarks = Regex("\\p{M}+")
private val nonAlphanumeric = Regex("[^a-z0-9]+")
private val whitespace = Regex("\\s+")
private val spanish: Locale = Locale.forLanguageTag("es-ES")

/** Texto sin tildes, en minúsculas y solo con letras, números y espacios simples. */
fun String.normalizeForSearch(): String =
    Normalizer.normalize(this, Normalizer.Form.NFD)
        .replace(combiningMarks, "")
        .lowercase(Locale.ROOT)
        .replace(nonAlphanumeric, " ")
        .trim()

/** Convierte nombres escritos en MAYÚSCULAS a formato título; el resto se deja tal cual. */
fun String.toDisplayName(): String {
    val trimmed = trim().replace(whitespace, " ")
    val hasLetters = trimmed.any { it.isLetter() }
    if (!hasLetters || trimmed != trimmed.uppercase(spanish)) return trimmed

    val result = StringBuilder(trimmed.length)
    var capitalizeNext = true
    for (ch in trimmed.lowercase(spanish)) {
        result.append(if (capitalizeNext && ch.isLetter()) ch.titlecaseChar() else ch)
        capitalizeNext = !ch.isLetterOrDigit()
    }
    return result.toString()
}
