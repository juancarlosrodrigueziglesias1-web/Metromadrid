package app.madridtrenmetro.ui.components

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.ui.graphics.Color
import app.madridtrenmetro.R
import app.madridtrenmetro.domain.model.TransportMode

@StringRes
fun TransportMode.labelRes(): Int = when (this) {
    TransportMode.METRO -> R.string.mode_metro
    TransportMode.CERCANIAS -> R.string.mode_cercanias
}

@DrawableRes
fun TransportMode.iconRes(): Int = when (this) {
    TransportMode.METRO -> R.drawable.ic_metro
    TransportMode.CERCANIAS -> R.drawable.ic_train
}

/** Color provisional del modo. Los colores por línea llegarán desde `routes.txt` en la fase 2. */
fun TransportMode.accentColor(): Color = when (this) {
    TransportMode.METRO -> Color(0xFF1E6FD9)
    TransportMode.CERCANIAS -> Color(0xFFC8102E)
}
