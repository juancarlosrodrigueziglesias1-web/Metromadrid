package app.madridtrenmetro.data.local

import app.madridtrenmetro.core.normalizeForSearch
import app.madridtrenmetro.domain.model.Station
import app.madridtrenmetro.domain.model.TransportMode

private const val STOP_SEPARATOR = "\u001F"

internal fun Station.toEntity(): StationEntity = StationEntity(
    id = id,
    name = name,
    searchName = name.normalizeForSearch(),
    mode = mode.name,
    stopIds = stopIds.joinToString(STOP_SEPARATOR),
    latitude = latitude,
    longitude = longitude,
)

internal fun StationEntity.toDomain(): Station? {
    val transportMode = TransportMode.fromName(mode) ?: return null
    return Station(
        id = id,
        name = name,
        mode = transportMode,
        stopIds = if (stopIds.isEmpty()) emptyList() else stopIds.split(STOP_SEPARATOR),
        latitude = latitude,
        longitude = longitude,
    )
}
