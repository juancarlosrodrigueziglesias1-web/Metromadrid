package app.madridtrenmetro.domain.source

import app.madridtrenmetro.domain.model.Arrival
import app.madridtrenmetro.domain.model.DataQuality
import app.madridtrenmetro.domain.model.Station
import app.madridtrenmetro.domain.model.TransportMode

/**
 * Fuente de llegadas (fase 2). Cada implementación declara su [quality]: así los horarios
 * programados y los datos en tiempo real nunca se mezclan sin que la UI lo sepa.
 */
interface ArrivalsProvider {
    val mode: TransportMode
    val quality: DataQuality
    suspend fun arrivalsFor(station: Station): Result<List<Arrival>>
}
