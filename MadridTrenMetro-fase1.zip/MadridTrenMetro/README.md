# Madrid Tren & Metro — Fase 1

App Android (Kotlin + Jetpack Compose) para consultar estaciones de Metro de Madrid y Cercanías.
**Estado: fase 1 = proyecto base, catálogo de estaciones GTFS y buscador con autocompletado.**
Las llegadas (fase 2) todavía no están implementadas; la pantalla de estación lo indica sin mostrar datos inventados.

## Requisitos
- Android Studio reciente (Ladybug o superior) con JDK 17+ (incluido en Android Studio).
- Android SDK Platform 35 (Studio lo ofrece al abrir el proyecto).
- Conexión a internet en la primera sincronización de Gradle y en el primer arranque de la app.
- Dispositivo o emulador con Android 8.0 (API 26) o superior.

## Compilar e instalar el APK

### Con Android Studio (recomendado)
1. `File > Open` y elige la carpeta `MadridTrenMetro`. Espera a que termine la sincronización de Gradle
   (descargará Gradle 8.9 y las dependencias).
2. Ejecutar en un dispositivo: botón **Run** (▶).
3. Generar el APK de depuración: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
   Resultado: `app/build/outputs/apk/debug/app-debug.apk`.

### Desde la terminal
El repositorio no incluye `gradle-wrapper.jar` (binario). Genera el wrapper una vez con Gradle 8.9 instalado:

```bash
gradle wrapper --gradle-version 8.9
./gradlew testDebugUnitTest      # pruebas unitarias JVM
./gradlew assembleDebug          # APK de depuración
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
Define `ANDROID_HOME` (o `sdk.dir` en `local.properties`) apuntando al SDK de Android.

### Con GitHub Actions
Sube el proyecto a un repositorio de GitHub (rama `main`). El workflow `.github/workflows/android.yml` ejecuta las
pruebas y compila el APK en cada push. Descárgalo en la pestaña **Actions**: abre la ejecución y, en *Artifacts*,
`MadridTrenMetro-debug-apk`. También puedes lanzarlo a mano con *Run workflow*.

### APK de release
`assembleRelease` genera un APK **sin firmar**, que Android no instala. Para distribuirlo, usa
`Build > Generate Signed App Bundle / APK` en Android Studio y crea tu keystore.

## Arquitectura
Un único módulo `:app` con capas separadas por paquetes (`core`, `domain`, `data`, `di`, `ui`).
El dominio no depende de Android ni de la capa de datos.

- `domain`: modelos (`Station`, `TransportMode`, `Arrival`, `DataQuality`), `StationRepository` y el contrato
  `ArrivalsProvider` para la fase 2. Cada llegada llevará `DataQuality.REALTIME` o `SCHEDULED`.
- `data/gtfs`: lector CSV, parser de `stops.txt`, ensamblador de estaciones y descarga de zips GTFS.
- `data/source`: `StationSource` por modo y `StationSourceRegistry`; añadir EMT = nueva fuente + valor en `TransportMode`.
- `data/local`: Room (`stations`, `sync_state`). La sincronización de cada modo es atómica y independiente:
  si falla uno, se conservan sus datos anteriores y los demás modos no se ven afectados.
- `ui`: Compose Material 3, tema claro/oscuro del sistema, navegación con transiciones, estados de carga,
  error con reintento, aviso parcial y vacío.

## Fuentes de datos (fase 1)
Estaciones: feeds GTFS estáticos del Consorcio Regional de Transportes de Madrid (`data/source/FeedUrls.kt`).
Son datos de catálogo y horarios programados, **no** tiempo real. La versión vigente del GTFS de Metro está
en el Punto de Acceso Nacional (NAP), que requiere ApiKey; se integrará cuando dispongas de ella.
Las URLs de FeedUrls proceden de los registros públicos de feeds y **no se han podido probar contra los
servidores desde el entorno de desarrollo**.

## Qué NO está verificado todavía
- Compilación y ejecución: el entorno donde se escribió el código no tiene Android SDK ni red.
- Que las URLs de los feeds respondan hoy y que `stops.txt` tenga la estructura asumida.
- El comportamiento visual en dispositivo.

Antes de pasar a la fase 2, ejecuta `./gradlew testDebugUnitTest assembleDebug`, instala la app y comprueba:
1. Primer arranque con internet: aparece "Preparando estaciones…" y luego el buscador.
2. Escribir "sol", "atocha", "nuñez" devuelve resultados, y los filtros Metro/Cercanías funcionan.
3. Segundo arranque en modo avión: el buscador funciona con los datos guardados.
4. Primer arranque sin internet: pantalla de error con "Reintentar".
